# Activity 10 — Step Counter Dashboard

> **🛠️ Stack for this lesson** — Expo SDK 58 / React Native 0.88 + native platform APIs · runs in a development build on a real phone (native modules do not run in Expo Go).
> 📥 Template: [/learn/m2/template/activity-10-step-counter](/learn/m2/template/activity-10-step-counter)

A dashboard shell: today's number, a goal box and a seven-day chart. The Health Connect reading from Activity 09 and the iPhone manual path are already here. You save the goal, draw the ring, group steps by day and keep the numbers fresh.

**Time:** ~45 min core path, ~35 min second sitting · **Concept:** Concept 11 — Step Tracking and Goals

---

## What You'll Build

| # | TODO | File |
|---|------|------|
| 1 | Save and reload the daily goal, with 12,000 as the default | `lib/goal.js` |
| 2 | Draw a circular ring that fills in proportion to steps over goal, capped at 100% | `components/ProgressRing.js` |
| 3 | Group step records into one total per local day for the chart | `lib/aggregate.js` |
| 4 | Refresh when the app returns to the foreground and every 60 seconds | `App.js` |

There are no commented-out solutions in the code. Each TODO states an outcome, a way to check it and a question to answer in your Notes doc. Read what is already there, work out what each TODO asks for, and write it.

**Already in the starter:** `App.js` (layout, goal box, chart bars); `lib/healthConnect.js` and `lib/manualLog.js` (from Activity 09).

## Run It

```bash
npm install --legacy-peer-deps
npx expo start --dev-client
```

Open your **development build** (the app from Activity 19) on a phone that is on the same Wi-Fi as your computer. It finds the running server and loads your code. Native modules do not run in Expo Go.

Android with at least one day of step data, or the manual form on an iPhone. Keep the Activity 09 `app.json` plugin settings.

## Verify

Your activity is done when, on a real device:

- [ ] Today's step count appears within 2 seconds of opening the app.
- [ ] The ring fills in proportion to `steps / goal` and stops at 100%.
- [ ] A new goal persists across restarts.
- [ ] The seven-day chart shows one bar per day with realistic totals.
- [ ] Going to the background and back refreshes the count without a manual pull.

## Stretch

Optional. Pick one and write a short note in your Notes doc about what you tried:

- **Choose your theme.** Make the ring a different shape or colour for a purpose of your own (study minutes, water glasses) while keeping the same maths.
- Add a streak counter that grows when `steps >= goal` on a new day.
- Animate the ring fill with React Native's `Animated`.
- Show "X steps to go" under the ring.

## 🪞 Reflect on Your Work

Answer in 2-3 sentences each, in your Notes doc. Your tutor reads these as part of grading.

1. **What did you learn that you didn't know before?** Name the most surprising thing — a permission quirk, a platform difference, a debugging story.
2. **How did you collaborate with AI?** If you used Claude / ChatGPT / Cursor / Copilot, what part of the work did *you* contribute — the prompt, the verification, the design decision, the bug-fix? If you didn't use AI, what was the hardest thing to figure out alone?
3. **How do you know your code works?** Describe one specific thing you did to confirm — the device test you ran, the screenshot you took, the behavior you watched.

> AI is a great collaborator. Owning your thinking, verifying the output, and explaining your design choices is what *learning* looks like in this course.

## 📱 Device Evidence (required, 30% of grade)

Full marks need a real device, not a simulator or Expo's web preview. Link these in your Notes doc (`Activity 10 write-up`), under a heading **Device Notes**:

1. **`screenshot-portrait.png`** — one full-screen portrait screenshot from your device showing the ring and the chart with real data, with the status bar visible (the clock and battery prove it is a real device).
2. **`recording.mp4`** — a 30–60 second screen recording of your real device showing opening the dashboard, backgrounding it, walking a few steps and bringing it back.
3. **Device Notes** (80–150 words): the phone model and OS, what worked first try, the exact text of anything that broke, and what only the real phone showed you.

Grading: 70% feature works in code, 30% device evidence. "I tested in Expo Go web" is not device evidence.

## Submit

When the Verify checklist is green, submit the link to your Notes doc, then press **Mark as Complete**.

<!-- claude-template-fix: readme-v3 -->

<!-- claude-template-fix: notes-migration-v1 -->
