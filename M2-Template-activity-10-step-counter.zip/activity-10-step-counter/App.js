import React, { useCallback, useEffect, useState } from 'react';
import { Platform, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { prepareHealthConnect, readStepRecords } from './lib/healthConnect';
import { loadManualRecords, addManualRecord } from './lib/manualLog';
import { loadGoal, saveGoal } from './lib/goal';
import { dailyTotals, localDateKey } from './lib/aggregate';
import ProgressRing from './components/ProgressRing';
import ManualEntry from './components/ManualEntry';

const isAndroid = Platform.OS === 'android';

export default function App() {
  const [goal, setGoal] = useState(12000);
  const [goalText, setGoalText] = useState('12000');
  const [days, setDays] = useState([]); // [{ date, steps }] oldest first, 7 entries
  const [ready, setReady] = useState(!isAndroid);

  const refresh = useCallback(async () => {
    const records = isAndroid ? await readStepRecords(7) : await loadManualRecords();
    setDays(dailyTotals(records, 7));
  }, []);

  useEffect(() => {
    loadGoal().then((g) => {
      setGoal(g);
      setGoalText(String(g));
    });
    if (isAndroid) prepareHealthConnect().then(setReady);
  }, []);

  // TODO 4: Keep the numbers fresh without a manual pull.
  //
  // Outcome: once `ready` is true, refresh() runs straight away, again every time the app returns to
  //          the foreground from the background, and again every 60 seconds while the screen is open.
  //          When the screen goes away, nothing keeps running: no timer, no listener.
  // Verify:  background the app, walk 30 steps, bring it back: the count rises without any pull.
  //          Leave the screen and check the terminal: no more refresh logs.
  // Reflect (in your Notes doc): what would leak if you forgot the cleanup, and how would you notice?
  //
  // Your code below ↓
  useEffect(() => {
    if (!ready) return undefined;
    refresh();
    return undefined;
  }, [ready, refresh]);

  const onSaveGoal = async () => {
    const value = parseInt(goalText, 10);
    if (!Number.isFinite(value) || value <= 0) return;
    await saveGoal(value);
    setGoal(value);
  };

  const today = days.length ? days[days.length - 1].steps : 0;
  const best = Math.max(goal, ...days.map((d) => d.steps), 1);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>Today</Text>
        {!isAndroid && <Text style={styles.note}>Health Connect is Android only, so steps here are entered by hand.</Text>}
        <ProgressRing steps={today} goal={goal} />

        <View style={styles.goalRow}>
          <TextInput style={styles.input} value={goalText} onChangeText={setGoalText} keyboardType="number-pad" />
          <Pressable style={styles.button} onPress={onSaveGoal}>
            <Text style={styles.buttonText}>Set goal</Text>
          </Pressable>
        </View>

        {!isAndroid && (
          <ManualEntry onAdd={async (iso, count) => { await addManualRecord(iso, count); refresh(); }} />
        )}

        <Text style={styles.subtitle}>Last 7 days</Text>
        <View style={styles.chart}>
          {days.map((d) => (
            <View key={d.date} style={styles.barColumn}>
              <View style={[styles.bar, { height: Math.max(4, (d.steps / best) * 120) }]} />
              <Text style={styles.barLabel}>{d.date.slice(8)}</Text>
              <Text style={styles.barValue}>{d.steps >= 1000 ? `${(d.steps / 1000).toFixed(1)}k` : d.steps}</Text>
            </View>
          ))}
        </View>
        <Text style={styles.note}>Today is {localDateKey(new Date())}.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  content: { padding: 20, paddingTop: 56, alignItems: 'center' },
  title: { fontSize: 24, fontWeight: '700', alignSelf: 'flex-start', marginBottom: 8 },
  subtitle: { fontSize: 18, fontWeight: '600', alignSelf: 'flex-start', marginTop: 24, marginBottom: 8 },
  note: { color: '#5f6368', marginVertical: 8, alignSelf: 'flex-start' },
  goalRow: { flexDirection: 'row', marginTop: 16, alignSelf: 'stretch' },
  input: { flex: 1, borderWidth: 1, borderColor: '#c4c7c5', borderRadius: 8, paddingHorizontal: 12, height: 44 },
  button: { marginLeft: 8, backgroundColor: '#188038', paddingHorizontal: 18, justifyContent: 'center', borderRadius: 8 },
  buttonText: { color: '#fff', fontWeight: '600' },
  chart: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', alignSelf: 'stretch', height: 180 },
  barColumn: { alignItems: 'center', flex: 1 },
  bar: { width: 22, backgroundColor: '#4285F4', borderRadius: 4 },
  barLabel: { marginTop: 4, color: '#5f6368', fontSize: 12 },
  barValue: { fontSize: 11, color: '#202124' },
});
