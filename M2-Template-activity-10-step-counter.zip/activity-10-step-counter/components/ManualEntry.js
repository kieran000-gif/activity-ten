import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';

// Provided: a tiny form for typing in a day's steps when Health Connect is not an option.
export default function ManualEntry({ onAdd }) {
  const [text, setText] = useState('');
  const submit = () => {
    const steps = parseInt(text, 10);
    if (Number.isNaN(steps) || steps < 0) return;
    onAdd(new Date().toISOString(), steps);
    setText('');
  };
  return (
    <View style={styles.row}>
      <TextInput style={styles.input} value={text} onChangeText={setText} keyboardType="number-pad" placeholder="Steps today" />
      <Pressable style={styles.button} onPress={submit}>
        <Text style={styles.buttonText}>Add</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', marginBottom: 12 },
  input: { flex: 1, borderWidth: 1, borderColor: '#c4c7c5', borderRadius: 8, paddingHorizontal: 12, height: 44 },
  button: { marginLeft: 8, backgroundColor: '#188038', paddingHorizontal: 18, justifyContent: 'center', borderRadius: 8 },
  buttonText: { color: '#fff', fontWeight: '600' },
});
