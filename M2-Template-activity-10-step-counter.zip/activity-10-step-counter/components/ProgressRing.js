import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';

// Provided: the ring is drawn in a 100 x 100 box with this radius and stroke width.
const RADIUS = 40;
const STROKE = 10;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

// TODO 2: Turn steps and goal into a ring that fills clockwise from the top.
//
// Outcome: ringOffset(steps, goal) returns how much of the circle's outline is left hidden so that
//          exactly steps / goal of it shows, never more than 100% and never below 0%. The ring below
//          draws a grey track and a green arc on top; make the arc fill clockwise starting at 12 o'clock
//          in proportion to the offset you computed, and keep it a rounded stroke.
// Verify:  console.log(ringOffset(6000, 12000)) and compare it with the value you predicted in your Notes
//          doc; the ring is half full. 20000 steps against 12000 shows a full ring, not a broken one.
// Reflect (in your Notes doc): what goes wrong when steps pass the goal and you do not cap the fraction?
//
// Your code below ↓
export function ringOffset(steps, goal, circumference = CIRCUMFERENCE) {
  return circumference;
}

export default function ProgressRing({ steps, goal, size = 200 }) {
  const offset = ringOffset(steps, goal);
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} viewBox="0 0 100 100">
        <Circle cx="50" cy="50" r={RADIUS} stroke="#e8eaed" strokeWidth={STROKE} fill="none" />
        {/* TODO 2: the green arc (stroke #188038, width STROKE) goes here, using `offset`. */}
      </Svg>
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <View style={styles.center}>
          <Text style={styles.steps}>{steps.toLocaleString()}</Text>
          <Text style={styles.goal}>of {goal.toLocaleString()}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  steps: { fontSize: 32, fontWeight: '700' },
  goal: { color: '#5f6368' },
});
